package com.clmapp.workerbees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ClaimDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimDemoApplication.class, args);

	}
}
